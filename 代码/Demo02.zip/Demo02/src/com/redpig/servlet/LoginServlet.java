package com.redpig.servlet;

import com.redpig.beans.User;
import com.redpig.dao.UserDao;
import com.redpig.dao.UserDaoImpl;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取到用户输入的用户名和密码，进行登陆业务的处理
        /**
         * HttpServletRequest：请求对象。servlet容器会在请求到达后，创建一个request对象，将http请求的信息全部封装到该对象中
         */

        //设置请求时候的内容编码
        req.setCharacterEncoding("utf-8");
        //获取用户名
        String username = req.getParameter("username");
        //获取密码
        String  password =  req.getParameter("password");

        System.out.println("username: "+ username + "   password: "+ password);


        //设置响应内容类型（设置响应的编码）
        resp.setContentType("text/html ; charset=UTF-8");
        //获取打印流
        PrintWriter out =  resp.getWriter();

        UserDao userDao = new UserDaoImpl();
        User user = userDao.getUserByUserNameAndPassWord(username, password);

        if (user == null){

            //通过重定向的方式去登陆页面
            /**
             * 服务器会给页面发送一个302状态码和一个新的地址
             */
//            resp.sendRedirect("login.html");
//            resp.sendRedirect("login.jsp");
            /**
             * 转发：
             */
            //转发之前，需要绑定数据，就是将想要交给下一个组件（jsp）处理数据，绑定到request对象中
            req.setAttribute("login_msg","用户名或密码错误");
            //获取转发器
            RequestDispatcher requestDispatcher = req.getRequestDispatcher("login.jsp");
            //开始转发
            requestDispatcher.forward(req,resp);

//           String str =
//                  " <!DOCTYPE html>"+
//                          "<html lang='en'>"+
//                          "<head>"+
//                          "<meta charset='UTF-8'>"+
//                          "<title>登陆</title>"+
//                          "<style>"+
//                          " body{"+
//                          "background-color: pink;"+
//                          "}"+
//                          "</style>"+
//                          "</head>"+
//                          "<body>"+
//                          "<h1>欢迎登陆！！！</h1>"+
//
//                          "<form action='login' method='post'>"+
//                          " 用户名：<input type='text' name='username' value= '"+username+"'><span><font color='red'>用户名或密码错误</font></span>"+
//            "<br />"+
//                    " 密　码：<input type='password' name='password'>"+
//                          " <br />"+
//                          "<input type='submit' value='login'>"+
//                          "</form>"+
//                          "</body>"+
//                          "</html>";
//           out.println(str);
        }else {
            out.println("<h1>login success :登陆成功</ h1>");
        }


        //验证用户名与密码是否正确
//        if ("admin".equalsIgnoreCase(username) && "123123".equals(password)){
//            //登陆成功
//           out.println("<h1>login success :登陆成功</ h1>");
//        }else{
//            //登陆失败
//            out.println("<h1>login fail :登陆失败</h1>");
//        }

    }
}
