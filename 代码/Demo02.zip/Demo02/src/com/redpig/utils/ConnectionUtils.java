package com.redpig.utils;


import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;

import java.util.Properties;

public class ConnectionUtils {
    /**
     * 使用静态代码块读取db.properties
     */
    private static String driver = null;
    private static String url = null;
    private static String username = null;
    private static String password = null;
    private static Properties properties = new Properties();

    /**
     *threadlocal：保证一个线程只能有一个连接
     */
    private  static ThreadLocal<Connection> threadLocal = new ThreadLocal<>();

    //静态代码块只执行一次
    static{
        try {
            //类加载器读取文件
            InputStream resourceAsStream = ConnectionUtils.class.getClassLoader().getResourceAsStream("db.properties");
            properties.load(resourceAsStream);
            driver = properties.getProperty("jdbc.driver");
            url = properties.getProperty("jdbc.url");
            username = properties.getProperty("jdbc.username");
            password = properties.getProperty("jdbc.password");

            Class.forName("com.mysql.cj.jdbc.Driver");

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    /**
     * 获取连接的方法
     */
    public static  Connection getConnection() throws Exception {
        //先尝试从threadlocal获取
        Connection connection = threadLocal.get();
        if (connection == null){
             connection = DriverManager.getConnection(url, username, password);
            threadLocal.set(connection);
        }
        return connection;
    }


    /**
     * 关闭连接
     */

    public static  void closeConnection() throws Exception{
        Connection connection = threadLocal.get();
        if (connection != null){
            connection.close();
        }
        threadLocal.set(null);
    }

    public static void main(String[] args)throws Exception {
        Connection connection1 = getConnection();
        closeConnection();
        Connection connection2 = getConnection();
        System.out.println(connection1 == connection2);
    }

}
