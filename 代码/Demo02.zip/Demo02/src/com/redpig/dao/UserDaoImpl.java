package com.redpig.dao;

import com.redpig.beans.User;
import com.redpig.utils.ConnectionUtils;

import java.sql.*;

public class UserDaoImpl implements UserDao {
    @Override
    public User getUserByUserNameAndPassWord(String username, String password) {
        //JDBC ：获取连接    编写SQL  预编译SQL  设置参数   执行SQl 封装结果   关闭连接

        User user1 = null;

        try {
//            Class.forName("com.mysql.cj.jdbc.Driver");
//            String url = "jdbc:mysql://localhost:3306/bigtata?serverTimezone=CTT&useUnicode=true&characterEncoding=utf-8&allowMultiQueries=true";
//            String user = "root";
//            String pawd = "root";
           //获取连接
//            Connection connection = DriverManager.getConnection(url, user, pawd);

            Connection connection = ConnectionUtils.getConnection();

            //编写SQL
            String sql = "select id, username, password from tbl_user where username=? and password=?";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1,username);
            preparedStatement.setString(2,password);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()){

                user1 = new User();
                user1.setId(resultSet.getInt("id"));
                user1.setUsername(resultSet.getString("username"));
                user1.setPassword(resultSet.getString("password"));


            }

            return  user1;


        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try {
                ConnectionUtils.closeConnection();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }


        return null;
    }
}
