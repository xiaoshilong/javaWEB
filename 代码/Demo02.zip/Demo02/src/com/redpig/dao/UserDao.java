package com.redpig.dao;

import com.redpig.beans.User;

public interface UserDao {
    public User getUserByUserNameAndPassWord(String username, String password);
}
